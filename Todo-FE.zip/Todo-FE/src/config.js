
const LOCAL_URL= "http://localhost:3000"

const PRODUCTION_URL = ""

export default LOCAL_URL;